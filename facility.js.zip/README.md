# facility.js

Biblioteca 100% brasileira para criar bots de Discord em JavaScript. Toda a API — classes, métodos e eventos — é em português.

## Instalação

```bash
npm install
```

## Uso básico

```js
const { Cliente, Intencoes, combinar } = require('facility.js');

const cliente = new Cliente({
  intencoes: combinar(Intencoes.SERVIDORES, Intencoes.MENSAGENS_DO_SERVIDOR, Intencoes.CONTEUDO_DE_MENSAGEM),
});

cliente.on('pronto', () => {
  console.log(`Logado como ${cliente.usuario.username}`);
});

cliente.on('mensagemCriada', (mensagem) => {
  if (mensagem.conteudo === '!ping') {
    mensagem.responder('Pong!');
  }
});

cliente.entrar('SEU_TOKEN_AQUI');
```

## Uso enxuto (`criar`)

Pra não escrever `require` desestruturado, `new Cliente(...)`, registrar cada comando à mão e chamar `.entrar()`, existe o atalho `criar()`, que faz tudo isso numa chamada só:

```js
require('facility.js').criar({
  prefixo: '!',
  intencoes: ['SERVIDORES', 'MENSAGENS_DO_SERVIDOR', 'CONTEUDO_DE_MENSAGEM'], // strings, sem precisar de combinar()
  comandos: './comandos',        // carrega todo .js dessa pasta como comando
  banco: { tipo: 'arquivo', caminho: './dados.json' }, // opcional; padrão é memória
  token: 'SEU_TOKEN_AQUI',
  depuracao: true,               // opcional, loga eventos internos
});
```

Cada arquivo dentro de `./comandos` exporta `{ nome, codigo }`:

```js
// comandos/ping.js
module.exports = { nome: 'ping', codigo: '#texto[Pong! 🏓]' };
```

Se preferir montar na mão (mais controle, sem o atalho `criar`), o equivalente é:

```js
const { Cliente } = require('facility.js');

const cliente = new Cliente({
  prefixo: '!',
  intencoes: ['SERVIDORES', 'MENSAGENS_DO_SERVIDOR', 'CONTEUDO_DE_MENSAGEM'],
  banco: { tipo: 'arquivo', caminho: './dados.json' },
});

cliente.carregarComandos('./comandos');
cliente.entrar('SEU_TOKEN_AQUI');
```

## Banco de dados

`#definirVar[]` / `#pegarVar[]` usam o banco configurado em `banco`:

| Tipo | Comportamento |
|---|---|
| `memoria` (padrão) | Fica só em RAM, some ao reiniciar o bot |
| `arquivo` | Persiste em JSON no `caminho` informado, sobrevive a reinícios |

Fora do sistema `#funcao[]`, dá pra acessar direto: `cliente.variaveis.definir('chave', 'valor')` e `cliente.variaveis.pegar('chave')`.

## Música

Sistema de voz completo: conecta no canal, decodifica qualquer áudio (ffmpeg) e manda pro Discord via UDP/RTP criptografado. Precisa do intent `ESTADOS_DE_VOZ` pra saber em qual canal o autor está.

```js
require('facility.js').criar({
  prefixo: '!',
  intencoes: ['SERVIDORES', 'MENSAGENS_DO_SERVIDOR', 'CONTEUDO_DE_MENSAGEM', 'ESTADOS_DE_VOZ'],
  comandos: './comandos',
  token: 'SEU_TOKEN_AQUI',
});
```

Pelo sistema `#funcao[]` (entra sozinho no canal de voz que o autor da mensagem está):

```js
cliente.comando('tocar', { codigo: '#tocar[#argumento[0]]' });   // !tocar <url>
cliente.comando('pausar', { codigo: '#pausar[]' });
cliente.comando('retomar', { codigo: '#retomar[]' });
cliente.comando('pular', { codigo: '#pular[]' });
cliente.comando('parar', { codigo: '#pararMusica[]' });
cliente.comando('volume', { codigo: '#volume[#argumento[0]]' });  // !volume 150 (0-200)
cliente.comando('fila', { codigo: '#fila[]' });
```

Ou direto pela API do `Cliente` (útil num handler de slash command, por exemplo):

```js
cliente.comandoBarra(comando, async (interacao) => {
  await cliente.tocar(interacao.servidorId, canalVozId, { url: 'https://.../musica.mp3' });
  await interacao.responder('Tocando! 🎵');
});

cliente.pausarMusica(servidorId);
cliente.retomarMusica(servidorId);
cliente.pularMusica(servidorId);       // também avança a fila se nada estiver tocando
cliente.pararMusica(servidorId);       // limpa a fila e sai do canal
cliente.definirVolumeMusica(servidorId, 150); // 0-200
cliente.filaDeMusica(servidorId);      // { faixas, indiceAtual, volume, repetir, ... }
```

**Fonte de áudio:** `#tocar[url]` aceita qualquer link http(s) direto pra um arquivo/stream de áudio, ou caminho de arquivo local — tudo que o `ffmpeg` conseguir abrir. Não tem extração de YouTube embutida (isso exige lidar com a assinatura do player deles); se precisar disso, resolva a URL de stream com uma lib como `play-dl` antes de chamar `#tocar[]`/`cliente.tocar()`.

Eventos: `musicaComecou` (`{ servidorId, faixa }`), `filaVazia` (`servidorId`), `saiuDoCanalDeVoz` (`servidorId`).

**Dependências:** `prism-media`, `tweetnacl`, `opusscript` e `ffmpeg-static` (todas instaladas via `npm install`, sem precisar de ffmpeg no sistema).

## Códigos de erro

A partir de certos pontos internos, a lib não solta o erro cru do JavaScript direto no console/logs — ela embrulha num `ErroFacility`, com um **código consultável** e uma mensagem em português. O erro original nunca é descartado: fica acessível em `erro.causaOriginal`.

```js
cliente.on('erro', (erro) => {
  console.log(erro.codigo);          // ex: "FCLY-MOTOR-53"
  console.log(erro.message);         // "[FCLY-MOTOR-53] Uma função do sistema #funcao[] lançou um erro..."
  console.log(erro.causaOriginal);   // o Error original do JS, se quiser debugar a fundo
});
```

O `criar()` já registra um handler padrão que imprime só `[facility.js] [CODIGO] mensagem`, sem o stack trace cru por cima.

| Código | Onde acontece | Causa comum |
|---|---|---|
| `FCLY-GATEWAY-41` | Conexão com o gateway fechada com código fatal | Token inválido, intent privilegiado sem estar habilitado no Developer Portal |
| `FCLY-GATEWAY-17` | Erro na conexão WebSocket | Falha de rede, DNS, proxy bloqueando `gateway.discord.gg` |
| `FCLY-REST-22` | Requisição HTTP pra API do Discord falhou | Payload inválido, permissão do bot insuficiente no servidor, canal/ID errado |
| `FCLY-REST-90` | Requisição retornou 401/403 | Token errado, revogado, ou faltando permissão pro endpoint |
| `FCLY-DB-08` | Falha ao salvar o banco em arquivo | Disco cheio, sem permissão de escrita no `caminho` configurado |
| `FCLY-MOTOR-53` | Uma função `#funcao[]` (built-in ou registrada com `registrarFuncao`) lançou erro | Bug numa função custom, argumento em formato inesperado |
| `FCLY-COMANDO-14` | `carregarComandos()` chamado com pasta inexistente | Caminho errado passado pro `criar()` ou `.carregarComandos()` |
| `FCLY-COMANDO-61` | Erro ao processar um comando de texto (prefixo) | Erro não tratado dentro do código `#funcao[]` do comando |
| `FCLY-BARRA-35` | Erro no handler de um comando de barra (slash) | Exception dentro da função passada em `cliente.comandoBarra(comando, executar)` |
| `FCLY-CONFIG-09` | Intent desconhecido passado em `intencoes` | Nome de intent escrito errado (confira a lista em `Intencoes`) |

## Estrutura

```
facility.js/
├── index.js                    # ponto de entrada + atalho criar()
├── example.js                  # exemplo completo (slash commands, botões, modais)
├── exemplo-enxuto.js           # exemplo curto usando criar()
├── comandos/                   # comandos carregados via cliente.carregarComandos()
│   ├── ping.js
│   └── perfil.js
├── package.json
└── src/
    ├── Cliente.js               # une gateway + rest, emite eventos de alto nível
    ├── ClienteGateway.js        # WebSocket, heartbeat, resume, reconexão
    ├── ClienteRest.js           # requisições HTTP com rate limit por bucket
    ├── Intencoes.js             # bitfield de intents (Intenções) + resolver() por string
    ├── BancoDados.js            # banco chave-valor: memória ou arquivo JSON
    ├── ErroFacility.js          # erro customizado com código consultável (FCLY-...)
    ├── ComandosGerenciador.js   # registra comandos e carrega de pasta
    ├── voz/
    │   ├── GerenciadorVoz.js    # entra em canal, junta handshake, mantém filas
    │   ├── ConexaoVoz.js        # voice gateway + UDP + RTP + criptografia
    │   ├── CodificadorAudio.js  # ffmpeg -> volume -> Opus
    │   └── FilaMusica.js        # fila de reprodução por servidor
    └── estruturas/
        └── Mensagem.js          # classe com .responder() e .enviarNoCanal()
```

## Eventos disponíveis

| Evento | Quando dispara |
|---|---|
| `pronto` | Conexão estabelecida e cliente autenticado |
| `mensagemCriada` | Uma mensagem é criada em um canal |
| `depuracao` | Mensagens internas de debug |
| `erro` | Erro no gateway |
| `bruto` | Qualquer evento do gateway não tratado explicitamente |
| `comandoBarraExecutado` | Um slash command foi chamado (dispara antes do handler rodar) |
| `botaoClicado` | Alguém clicou em um botão |
| `menuSelecionado` | Alguém escolheu opção(ões) em um select menu |
| `modalEnviado` | Um modal foi enviado (submit) |
| `autocompleteSolicitado` | Discord pediu sugestões de autocomplete de uma opção |

## API do Cliente

- `cliente.entrar(token)` — conecta ao Discord
- `cliente.usuario` — dados do bot autenticado
- `cliente.servidores` — Map de servidores (guilds) em cache
- `cliente.rest` — instância de `ClienteRest` para chamadas diretas à API

## API da Mensagem

- `mensagem.responder(conteudo)` — responde citando a mensagem original
- `mensagem.enviarNoCanal(conteudo)` — envia uma mensagem nova no mesmo canal

## Sistema de comandos por código (`#funcao[]`)

Assim como o aoi.js usa `$titulo[]`, aqui usamos `#titulo[]`. Registre um comando com `cliente.comando(nome, { codigo })` — o resultado é enviado automaticamente no canal ao final da execução (não precisa chamar nada pra "enviar").

```js
cliente.comando('perfil', {
  codigo: `
    #titulo[Perfil de #nomeAutor[]]
    #cor[AZUL]
    #descricao[Olá, #mencaoAutor[]! Você está no servidor #idServidor[].]
    #campo[ID do canal;#idCanal[];true]
  `,
});
```

Funções aninhadas funcionam: `#cor[#pegarVar[corPadrao]]`. Argumentos são separados por `;`. Pra usar `;`, `[`, `]` ou `#` literais, escape com `\`.

### Funções disponíveis

| Função | Uso |
|---|---|
| `#titulo[texto]` | Define o título do embed |
| `#descricao[texto]` | Define a descrição do embed |
| `#cor[nome ou hex]` | Cor do embed (`VERMELHO`, `VERDE`, `AZUL`, `AMARELO`, `ROXO`, `LARANJA`, `PRETO`, `BRANCO`, `CINZA`, ou hex tipo `#ff0000`) |
| `#imagem[url]` | Imagem grande do embed |
| `#thumbnail[url]` | Miniatura do embed |
| `#rodape[texto;iconeUrl]` | Rodapé do embed |
| `#autorEmbed[nome;iconeUrl]` | Autor exibido no embed |
| `#campo[nome;valor;inline]` | Adiciona um campo ao embed (`inline` é `true` ou `false`) |
| `#texto[conteudo]` | Texto simples enviado junto (fora do embed) |
| `#mencaoAutor[]` | Menção de quem executou o comando |
| `#nomeAutor[]` | Nome de usuário de quem executou |
| `#idAutor[]` / `#idCanal[]` / `#idServidor[]` | IDs do contexto atual |
| `#argumento[indice]` | Argumento do comando pela posição (0, 1, 2...) |
| `#argumentos[]` | Todos os argumentos juntos |
| `#totalArgumentos[]` | Quantidade de argumentos passados |
| `#definirVar[nome;valor]` / `#pegarVar[nome]` | Variáveis em memória, compartilhadas entre comandos |
| `#se[condicao;entao;senao]` | Condicional simples com `==`, `!=`, `>`, `<`, `>=`, `<=` |

### Criando novas funções

```js
const { registrarFuncao } = require('facility.js');

registrarFuncao('maiusculo', (args) => (args[0] ?? '').toUpperCase());
```

Agora `#maiusculo[ola mundo]` funciona em qualquer comando.

## Slash commands (comandos de barra)

```js
const { ComandoBarra } = require('facility.js');

const comando = new ComandoBarra('perfil', 'Mostra um cartão de perfil')
  .adicionarOpcaoUsuario('usuario', 'De quem ver o perfil', { obrigatorio: false });

cliente.comandoBarra(comando, async (interacao) => {
  const idUsuario = interacao.opcao('usuario');
  await interacao.responder('Aqui está o perfil!');
});

cliente.on('pronto', async () => {
  // servidorId propaga na hora (bom pra testar); sem ele, registra globalmente (demora até 1h)
  await cliente.sincronizarComandosBarra({ servidorId: 'ID_DO_SEU_SERVIDOR' });
});
```

`ComandoBarra` aceita `.adicionarOpcaoTexto()`, `.adicionarOpcaoInteiro()`, `.adicionarOpcaoBooleano()`, `.adicionarOpcaoUsuario()`, `.adicionarOpcaoCanal()`.

### Métodos da interação (`Interacao`)

- `interacao.responder(conteudo, { efemero })` — responde (efêmero = só quem executou vê)
- `interacao.deferir({ efemero })` — avisa "pensando..." quando a resposta demora mais de 3s
- `interacao.editarResposta(conteudo)` — edita a resposta já enviada
- `interacao.enviarSeguimento(conteudo)` — manda uma mensagem extra depois da resposta
- `interacao.atualizarMensagem(conteudo)` — edita a mensagem original (usado em botão/menu)
- `interacao.mostrarModal(modal)` — abre um modal
- `interacao.opcao(nome)` — valor de uma opção do slash command
- `interacao.camposModal()` — `{ customId: valor }` de um modal enviado
- `interacao.valores` — array de valores escolhidos (select menu)
- `interacao.customId` — id do componente clicado/enviado

## Botões

Dá pra usar dentro do sistema `#funcao[]`:

```js
cliente.comando('confirmar', {
  codigo: `
    #texto[Tem certeza?]
    #botao[Sim;confirmar_sim;SUCESSO]
    #botao[Não;confirmar_nao;PERIGO]
  `,
});
```

Estilos: `PRIMARIO`, `SECUNDARIO`, `SUCESSO`, `PERIGO`. `#linkBotao[rotulo;url]` cria um botão de link. `#novaLinha[]` força quebra de linha (por padrão quebra sozinho a cada 5 botões).

Ou via builder, pra mais controle (útil fora do sistema de comando por texto):

```js
const { Botao, LinhaAcao } = require('facility.js');

const linha = new LinhaAcao().adicionar(
  new Botao().definirId('btn_sim').definirRotulo('Sim').definirEstilo(3),
  new Botao().definirId('btn_nao').definirRotulo('Não').definirEstilo(4),
);

mensagem.enviarNoCanal({ content: 'Confirma?', components: [linha.construir()] });
```

Escute o clique com `cliente.on('botaoClicado', (interacao) => { ... })`.

## Select menus

```js
const { MenuSelecao, LinhaAcao } = require('facility.js');

const linha = new LinhaAcao().adicionar(
  new MenuSelecao()
    .definirId('menu_cor')
    .definirPlaceholder('Escolha uma cor')
    .adicionarOpcao({ rotulo: 'Vermelho', valor: 'vermelho' })
    .adicionarOpcao({ rotulo: 'Azul', valor: 'azul' }),
);

mensagem.enviarNoCanal({ content: 'Escolha:', components: [linha.construir()] });
```

Escute com `cliente.on('menuSelecionado', (interacao) => { ... interacao.valores })`.

## Modais

```js
const { Modal, CampoTexto } = require('facility.js');

const modal = new Modal()
  .definirId('modal_feedback')
  .definirTitulo('Seu feedback')
  .adicionarCampo(new CampoTexto().definirId('campo_msg').definirRotulo('Mensagem').obrigatorio());

await interacao.mostrarModal(modal);
```

Só pode ser aberto a partir de uma interação (slash command ou clique de botão/menu). Escute o envio com `cliente.on('modalEnviado', (interacao) => { interacao.camposModal() })`.
