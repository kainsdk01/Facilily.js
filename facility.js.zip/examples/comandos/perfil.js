module.exports = {
  nome: 'perfil',
  codigo: `
    #titulo[Perfil de #nomeAutor[]]
    #cor[AZUL]
    #descricao[Olá, #mencaoAutor[]! Você está no servidor #idServidor[].]
  `,
};
