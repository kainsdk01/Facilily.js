// Qualquer arquivo .js aqui dentro vira um comando automaticamente
// quando você usa cliente.carregarComandos("./comandos").
module.exports = {
  nome: 'ping',
  codigo: `#texto[Pong! 🏓]`,
};
