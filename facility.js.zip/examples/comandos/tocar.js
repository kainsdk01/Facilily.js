// Uso: !tocar https://exemplo.com/musica.mp3
// #argumento[0] pega a URL passada depois do comando.
module.exports = {
  nome: 'tocar',
  codigo: `#tocar[#argumento[0]]`,
};
