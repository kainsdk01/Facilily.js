const {
  Cliente, Intencoes, combinar,
  ComandoBarra, Botao, LinhaAcao, MenuSelecao, Modal, CampoTexto,
} = require('facility.js');

const cliente = new Cliente({
  prefixo: '!',
  intencoes: combinar(Intencoes.SERVIDORES, Intencoes.MENSAGENS_DO_SERVIDOR, Intencoes.CONTEUDO_DE_MENSAGEM),
});

// ---- Comando por prefixo com botões via #funcao[] ----
cliente.comando('confirmar', {
  codigo: `
    #texto[Tem certeza?]
    #botao[Sim;confirmar_sim;SUCESSO]
    #botao[Não;confirmar_nao;PERIGO]
  `,
});

// ---- Slash command ----
const comandoPerfil = new ComandoBarra('perfil', 'Mostra um cartão de perfil')
  .adicionarOpcaoUsuario('usuario', 'De quem ver o perfil', { obrigatorio: false });

cliente.comandoBarra(comandoPerfil, async (interacao) => {
  await interacao.responder({
    embeds: [{ title: 'Perfil', description: `Solicitado por <@${interacao.usuario.id}>`, color: 0x3498db }],
  });
});

// ---- Slash command que abre um modal ----
const comandoFeedback = new ComandoBarra('feedback', 'Enviar um feedback');

cliente.comandoBarra(comandoFeedback, async (interacao) => {
  const modal = new Modal()
    .definirId('modal_feedback')
    .definirTitulo('Seu feedback')
    .adicionarCampo(new CampoTexto().definirId('campo_msg').definirRotulo('Mensagem').obrigatorio());

  await interacao.mostrarModal(modal);
});

// ---- Menu de seleção enviado manualmente ----
cliente.comando('escolher', {
  codigo: '#texto[Escolha uma opção abaixo:]',
});

cliente.on('mensagemCriada', async (mensagem) => {
  if (mensagem.conteudo === '!menu') {
    const linha = new LinhaAcao().adicionar(
      new MenuSelecao()
        .definirId('menu_cor')
        .definirPlaceholder('Escolha uma cor')
        .adicionarOpcao({ rotulo: 'Vermelho', valor: 'vermelho' })
        .adicionarOpcao({ rotulo: 'Azul', valor: 'azul' }),
    );
    await mensagem.enviarNoCanal({ content: 'Escolha:', components: [linha.construir()] });
  }
});

// ---- Eventos de interação ----
cliente.on('botaoClicado', async (interacao) => {
  if (interacao.customId === 'confirmar_sim') await interacao.atualizarMensagem({ content: 'Confirmado! ✅', components: [] });
  if (interacao.customId === 'confirmar_nao') await interacao.atualizarMensagem({ content: 'Cancelado. ❌', components: [] });
});

cliente.on('menuSelecionado', async (interacao) => {
  await interacao.responder(`Você escolheu: ${interacao.valores[0]}`, { efemero: true });
});

cliente.on('modalEnviado', async (interacao) => {
  const campos = interacao.camposModal();
  await interacao.responder(`Recebi seu feedback: ${campos.campo_msg}`, { efemero: true });
});

cliente.on('pronto', async () => {
  console.log(`Logado como ${cliente.usuario.username}`);
  // Registra os slash commands só no servidor de testes (propaga na hora).
  await cliente.sincronizarComandosBarra({ servidorId: 'SEU_SERVIDOR_ID' });
});

cliente.on('depuracao', console.log);
cliente.on('erro', console.error);

cliente.entrar('SEU_TOKEN_AQUI');
