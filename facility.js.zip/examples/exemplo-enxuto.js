// Exemplo enxuto: uma chamada só monta o cliente, carrega comandos
// da pasta ./comandos, liga o banco de dados persistente e conecta.
require('facility.js').criar({
  prefixo: '!',
  intencoes: ['SERVIDORES', 'MENSAGENS_DO_SERVIDOR', 'CONTEUDO_DE_MENSAGEM'],
  comandos: './comandos',
  banco: { tipo: 'arquivo', caminho: './dados.json' }, // omita pra usar memória (não persiste)
  token: 'SEU_TOKEN_AQUI',
  depuracao: true, // mostra logs internos (conexão, comandos carregados, etc.)
});
