const { Cliente } = require('./src/Cliente');
const { Intencoes, combinar } = require('./src/Intencoes');
const { ClienteRest } = require('./src/ClienteRest');
const { ClienteGateway } = require('./src/ClienteGateway');
const { Mensagem } = require('./src/estruturas/Mensagem');
const { Interacao, TiposInteracao, TiposComponente } = require('./src/estruturas/Interacao');
const { registrar } = require('./src/motor/RegistroFuncoes');
const { ComandoBarra, TiposOpcao } = require('./src/construtores/ComandoBarra');
const { Botao, EstilosBotao } = require('./src/construtores/Botao');
const { LinhaAcao } = require('./src/construtores/LinhaAcao');
const { MenuSelecao, TiposMenu } = require('./src/construtores/MenuSelecao');
const { Modal, CampoTexto, EstilosCampoTexto } = require('./src/construtores/Modal');
const { BancoDados } = require('./src/BancoDados');
const { ErroFacility } = require('./src/ErroFacility');
const { GerenciadorVoz } = require('./src/voz/GerenciadorVoz');
const { ConexaoVoz } = require('./src/voz/ConexaoVoz');
const { FilaMusica } = require('./src/voz/FilaMusica');

/**
 * Monta um Cliente pronto pra rodar numa chamada só.
 *
 * require("facility.js").criar({
 *   prefixo: "!",
 *   intencoes: ["SERVIDORES", "MENSAGENS_DO_SERVIDOR", "CONTEUDO_DE_MENSAGEM"],
 *   comandos: "./comandos",
 *   banco: { tipo: "arquivo", caminho: "./dados.json" }, // opcional, padrão é memória
 *   token: "SEU_TOKEN_AQUI",
 * });
 *
 * Se "token" não for passado, o cliente é retornado sem conectar
 * (útil se você quiser registrar mais coisas antes de chamar .entrar() manualmente).
 */
function criar({ prefixo = '!', intencoes = [], comandos, banco, token, depuracao = false } = {}) {
  const cliente = new Cliente({ prefixo, intencoes, banco });

  if (depuracao) cliente.on('depuracao', console.log);
  cliente.on('erro', (erro) => {
    if (erro instanceof ErroFacility) {
      // Mostra só o código + mensagem amigável. O erro original (stack cru do
      // JS) fica em erro.causaOriginal, acessível se o usuário quiser debugar.
      console.error(`[facility.js] ${erro.message}`);
    } else {
      console.error(erro);
    }
  });
  cliente.on('pronto', () => cliente.emit('depuracao', `Logado como ${cliente.usuario?.username}`));

  if (comandos) cliente.carregarComandos(comandos);
  if (token) cliente.entrar(token);

  return cliente;
}

module.exports = {
  Cliente,
  criar,
  Intencoes,
  combinar,
  ClienteRest,
  ClienteGateway,
  Mensagem,
  registrarFuncao: registrar,
  Interacao,
  TiposInteracao,
  TiposComponente,
  ComandoBarra,
  TiposOpcao,
  Botao,
  EstilosBotao,
  LinhaAcao,
  MenuSelecao,
  TiposMenu,
  Modal,
  CampoTexto,
  EstilosCampoTexto,
  BancoDados,
  ErroFacility,
  GerenciadorVoz,
  ConexaoVoz,
  FilaMusica,
};
