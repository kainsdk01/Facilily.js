const { EventEmitter } = require('node:events');
const { ClienteGateway } = require('./ClienteGateway');
const { ClienteRest } = require('./ClienteRest');
const { Mensagem } = require('./estruturas/Mensagem');
const { ComandosGerenciador } = require('./ComandosGerenciador');
const { ComandosBarraGerenciador } = require('./ComandosBarraGerenciador');
const { BancoDados } = require('./BancoDados');
const { GerenciadorVoz } = require('./voz/GerenciadorVoz');
const { resolver: resolverIntencoes } = require('./Intencoes');

class Cliente extends EventEmitter {
  constructor({ intencoes = 0, prefixo = '!', banco } = {}) {
    super();
    this.intencoes = resolverIntencoes(intencoes);
    this.prefixo = prefixo;
    this.usuario = null;
    this.aplicacaoId = null;
    this.servidores = new Map();
    this.variaveis = new BancoDados(banco);
    this.variaveis.on('erro', (erro) => this.emit('erro', erro));
    this.comandosGerenciador = new ComandosGerenciador(this);
    this.comandosBarraGerenciador = new ComandosBarraGerenciador(this);
    this.gerenciadorVoz = new GerenciadorVoz(this);
  }

  comando(nome, opcoes) {
    this.comandosGerenciador.registrar(nome, opcoes);
    return this;
  }

  /** Carrega todos os comandos de uma pasta (cada arquivo exporta { nome, codigo }). */
  carregarComandos(caminhoPasta) {
    this.comandosGerenciador.carregarDePasta(caminhoPasta);
    return this;
  }

  /** Registra um comando de barra (slash command). Não sincroniza sozinho — use sincronizarComandosBarra(). */
  comandoBarra(definicao, executar) {
    this.comandosBarraGerenciador.registrar(definicao, executar);
    return this;
  }

  /** Envia os comandos de barra registrados pro Discord. Passe { servidorId } pra registrar só num servidor (propaga na hora, ótimo pra testar). */
  sincronizarComandosBarra(opcoes) {
    return this.comandosBarraGerenciador.sincronizar(opcoes);
  }

  // ---- Música ----

  /** Toca uma URL/arquivo no canal de voz (entra sozinho se ainda não estiver lá). Se já tiver algo tocando, entra na fila. */
  tocar(servidorId, canalVozId, faixa) {
    return this.gerenciadorVoz.tocar(servidorId, canalVozId, faixa);
  }

  pausarMusica(servidorId) {
    this.gerenciadorVoz.pausar(servidorId);
    return this;
  }

  retomarMusica(servidorId) {
    this.gerenciadorVoz.retomar(servidorId);
    return this;
  }

  pularMusica(servidorId) {
    this.gerenciadorVoz.pular(servidorId);
    return this;
  }

  pararMusica(servidorId) {
    this.gerenciadorVoz.pararMusica(servidorId);
    return this;
  }

  definirVolumeMusica(servidorId, volume) {
    this.gerenciadorVoz.definirVolume(servidorId, volume);
    return this;
  }

  filaDeMusica(servidorId) {
    return this.gerenciadorVoz.obterFila(servidorId);
  }

  entrar(token) {
    this.token = token;
    this.rest = new ClienteRest(token);
    this.gateway = new ClienteGateway(token, this.intencoes);

    this.gateway.on('depuracao', (msg) => this.emit('depuracao', msg));
    this.gateway.on('erro', (err) => this.emit('erro', err));
    this.gateway.on('dispatch', (evento, dados) => this.processarDispatch(evento, dados));

    this.gateway.conectar();
    return this;
  }

  processarDispatch(evento, dados) {
    switch (evento) {
      case 'READY':
        this.usuario = dados.user;
        this.aplicacaoId = dados.application?.id ?? this.usuario?.id ?? null;
        this.emit('pronto');
        break;

      case 'MESSAGE_CREATE': {
        const mensagem = new Mensagem(this, dados);
        this.emit('mensagemCriada', mensagem);
        this.comandosGerenciador.processarMensagem(mensagem).catch((erro) => this.emit('erro', erro));
        break;
      }

      case 'INTERACTION_CREATE':
        this.comandosBarraGerenciador.processar(dados).catch((erro) => this.emit('erro', erro));
        break;

      case 'GUILD_CREATE':
        this.servidores.set(dados.id, dados);
        break;

      case 'VOICE_STATE_UPDATE':
        this.gerenciadorVoz.processarEstadoVoz(dados);
        break;

      case 'VOICE_SERVER_UPDATE':
        this.gerenciadorVoz.processarServidorVoz(dados);
        break;

      default:
        this.emit('bruto', evento, dados);
    }
  }
}

module.exports = { Cliente };
