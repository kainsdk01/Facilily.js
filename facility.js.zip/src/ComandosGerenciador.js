const fs = require('node:fs');
const path = require('node:path');
require('./motor/FuncoesEmbutidas');
const { avaliarCodigo } = require('./motor/Analisador');
const { Contexto } = require('./motor/Contexto');
const { ErroFacility } = require('./ErroFacility');

class ComandosGerenciador {
  constructor(cliente) {
    this.cliente = cliente;
    this.comandos = new Map();
  }

  registrar(nome, opcoes) {
    this.comandos.set(nome.toLowerCase(), {
      nome: nome.toLowerCase(),
      codigo: opcoes.codigo,
    });
  }

  /**
   * Lê todos os arquivos .js de uma pasta e registra cada um como comando.
   * Cada arquivo deve exportar { nome, codigo }, por exemplo:
   *   module.exports = { nome: "ping", codigo: "#texto[Pong!]" };
   * Nome do arquivo não precisa bater com o nome do comando.
   */
  carregarDePasta(caminhoPasta) {
    const caminhoAbsoluto = path.resolve(caminhoPasta);

    if (!fs.existsSync(caminhoAbsoluto)) {
      throw new ErroFacility('COMANDO_PASTA_NAO_ENCONTRADA', `(${caminhoAbsoluto})`);
    }

    const arquivos = fs.readdirSync(caminhoAbsoluto).filter((arquivo) => arquivo.endsWith('.js'));

    let total = 0;
    for (const arquivo of arquivos) {
      const definicao = require(path.join(caminhoAbsoluto, arquivo));

      if (!definicao?.nome || !definicao?.codigo) {
        this.cliente.emit(
          'depuracao',
          `Ignorando "${arquivo}": precisa exportar { nome, codigo }.`,
        );
        continue;
      }

      this.registrar(definicao.nome, { codigo: definicao.codigo });
      total += 1;
    }

    this.cliente.emit('depuracao', `${total} comando(s) carregado(s) de ${caminhoAbsoluto}`);
    return total;
  }

  async processarMensagem(mensagem) {
    const prefixo = this.cliente.prefixo;
    if (!mensagem.conteudo?.startsWith(prefixo)) return;
    if (mensagem.autor?.bot) return;

    const semPrefixo = mensagem.conteudo.slice(prefixo.length).trim();
    const partes = semPrefixo.split(/\s+/);
    const nomeComando = partes.shift().toLowerCase();
    const argumentos = partes;

    const comando = this.comandos.get(nomeComando);
    if (!comando) return;

    const contexto = new Contexto(this.cliente, mensagem, argumentos);

    let conteudoFinal;
    try {
      conteudoFinal = await avaliarCodigo(comando.codigo, contexto);
    } catch (erro) {
      const erroFinal = erro instanceof ErroFacility
        ? erro
        : new ErroFacility('COMANDO_EXECUCAO_FALHOU', `(comando: ${nomeComando})`, erro);
      this.cliente.emit('erro', erroFinal);
      return;
    }

    await this.enviarResultado(mensagem, conteudoFinal, contexto.embed, contexto.componentes);
  }

  async enviarResultado(mensagem, conteudoFinal, embed, componentes) {
    const texto = conteudoFinal.trim();
    const temEmbed = Object.keys(embed).length > 0;
    const temComponentes = componentes && componentes.length > 0;

    if (!texto && !temEmbed && !temComponentes) return;

    const payload = {};
    if (texto) payload.content = texto;
    if (temEmbed) payload.embeds = [embed];
    if (temComponentes) payload.components = componentes;

    await mensagem.enviarNoCanal(payload);
  }
}

module.exports = { ComandosGerenciador };
